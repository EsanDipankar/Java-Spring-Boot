package com.TTL.SpringBootTest.service;

import com.TTL.SpringBootTest.entity.JournalEntry;
import com.TTL.SpringBootTest.repository.JournalEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JournalEntryService {

    @Autowired
    private JournalEntryRepository repository;

    public List<JournalEntry> getAllEntries() {
        return repository.findAll();
    }

    public JournalEntry getEntryById(int id) {
        return repository.findById(id).orElse(null);
    }

    public JournalEntry SaveEntry(JournalEntry entry) {
        return repository.save(entry);
    }
}
