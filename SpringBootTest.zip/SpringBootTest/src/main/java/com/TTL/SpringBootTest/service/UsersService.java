package com.TTL.SpringBootTest.service;

import com.TTL.SpringBootTest.entity.JournalEntry;
import com.TTL.SpringBootTest.entity.Users;
import com.TTL.SpringBootTest.repository.UsersRepository;
import org.apache.catalina.User;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Component
public class UsersService {

    @Autowired
    private UsersRepository usersRepository;

    public Users saveEntry(Users users){
        return usersRepository.save(users);
    }

    public List<Users> getAllEntries() {
        return usersRepository.findAll();
    }

    public Optional<Users> getEntryById(ObjectId id) {
        return usersRepository.findById(id);
    }

    public void DeleteByID(ObjectId id){usersRepository.deleteById(id); }

    public Users findbyUserName(String username){return usersRepository.findbyUserName(username);}

}
