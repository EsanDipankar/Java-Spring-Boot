package com.TTL.SpringBootTest.controller;

import com.TTL.SpringBootTest.entity.JournalEntry;
import com.TTL.SpringBootTest.service.JournalEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/journal")
public class JournalApplication {

    @Autowired
    private JournalEntryService journalEntryService;

    @PostMapping("/")  // explicitly map to /journal/
    public JournalEntry insertDate(@RequestBody JournalEntry myentry){
        return journalEntryService.SaveEntry(myentry);
    }

    @GetMapping("/")  // for getting all
    public List<JournalEntry> getAllData() {
        return journalEntryService.getAllEntries();
    }
}

