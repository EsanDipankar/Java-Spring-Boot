package com.TTL.SpringBootTest.repository;

import com.TTL.SpringBootTest.entity.JournalEntry;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface JournalEntryRepository extends MongoRepository<JournalEntry, Integer> {

}
