package com.TTL.SpringBootTest.controller;

import com.TTL.SpringBootTest.entity.JournalEntry;
import com.TTL.SpringBootTest.entity.Users;
import com.TTL.SpringBootTest.service.JournalEntryService;
import com.TTL.SpringBootTest.service.UsersService;
import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UsersService usersService;

    @GetMapping
    public List<Users> getAll(){
         return usersService.getAllEntries();
    }

    @PostMapping("/")  // explicitly map to /journal/
    public Users insertDate(@RequestBody Users myuser){
        return usersService.saveEntry(myuser);
    }

    @PutMapping("/")  // for getting all
    public ResponseEntity<?> updateUsers(@RequestBody Users user) {
        Users userinDB = usersService.findbyUserName(user.getUsername());
        if(userinDB != null){
            userinDB.setUsername(user.getUsername());
            userinDB.setPassword(user.getPassword());
            usersService.saveEntry(userinDB);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
}

