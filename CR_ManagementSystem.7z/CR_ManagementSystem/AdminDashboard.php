<?php
session_start();
include 'db.php';

// Check admin access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: index.php");
    exit();
}

// Admin info
$adminName = $_SESSION['admin_name'];

// Initialize status counts
$statusCounts = [
    "Raised" => 0,
    "Under Review" => 0,
    "Assigned" => 0,
    "In Progress" => 0,
    "Completed" => 0,
    "Delivered" => 0
];

// Fetch status counts
$statusQuery = "SELECT CR_Status, COUNT(*) AS count FROM cr_datatable GROUP BY CR_Status";
$statusResult = $conn->query($statusQuery);
while ($row = $statusResult->fetch_assoc()) {
    $statusCounts[$row['CR_Status']] = $row['count'];
}
$crList = $conn->query("SELECT *, Attachment FROM cr_datatable ORDER BY Created_On DESC");

// Fetch all CRs
$crList = $conn->query("SELECT * FROM cr_datatable ORDER BY Created_On DESC");

// Fetch all developers
$devResult = $conn->query("SELECT DeveloperID, DeveloperName FROM developers WHERE Current_Status='Available'");
$developers = [];
while ($d = $devResult->fetch_assoc()) {
    $developers[$d['DeveloperID']] = $d['DeveloperName'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard - CR Management System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin: 0; padding: 0; background-color: #f5f6fa; }
.wrapper { display: flex; min-height: 100vh; }
#sidebar { width: 240px; background: #2f3640; color: #fff; transition: width 0.3s ease; }
#sidebar.collapsed { width: 60px; }
#sidebar .nav-link { color: #fff; display: flex; align-items: center; gap: 10px; padding: 12px; }
#sidebar .nav-link:hover { background: #353b48; }
#sidebar.collapsed .nav-link span { display: none; }
.content { flex: 1; padding: 20px; }
.status-container { display: flex; flex-wrap: wrap; gap: 10px; justify-content: space-around; margin-bottom: 20px; }
.status-card {
    flex: 1;
    max-width: 180px;
    min-width: 140px;
    min-height: 130px;
    border-radius: 10px;
    color: white;
    padding: 15px;
    text-align: center;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.status-card .icon { font-size: 36px; margin-bottom: 8px; }
.status-card:hover { transform: scale(1.05); }
.status-card.raised { background-color: #00a8ff; }
.status-card.review { background-color: #9c88ff; }
.status-card.assigned { background-color: #fbc531; color: black; }
.status-card.progress { background-color: #e1b12c; color: black; }
.status-card.completed { background-color: #4cd137; }
.status-card.delivered { background-color: #44bd32; }
table { background: white; border-radius: 8px; }
.status-card.all { background-color: #576574; } /* Neutral gray-blue for 'All CRs' */

.active-card {
  box-shadow: 0 0 15px 3px rgba(255,255,255,0.4);
  transform: scale(1.05);
  border: 2px solid #fff;
}

</style>
</head>
<body>
<div class="wrapper">
  <!-- Sidebar -->
  <nav id="sidebar">
    <button id="toggle-btn" class="btn btn-link text-white mt-2" onclick="toggleSidebar()">☰</button>
    <h5 class="text-center mt-3">Admin Menu</h5>
    <ul class="nav flex-column mt-3">
  <li>
    <a href="AdminDashboard.php" class="nav-link">
      <i class="fa fa-home"></i><span> Dashboard</span>
    </a>
  </li>
  <li>
    <a href="raise_cr.php" class="nav-link">
      <i class="fa fa-upload"></i><span> Raise CR</span>
    </a>
  </li>
  <li>
    <a href="add_developer.php" class="nav-link">
      <i class="fa fa-user-plus"></i><span> Add Developer</span>
    </a>
  </li>
  <li>
    <a href="logout.php" class="nav-link">
      <i class="fa fa-sign-out-alt"></i><span> Logout</span>
    </a>
  </li>
</ul>

  </nav>

  <!-- Content -->
  <div class="content">
    <h3 class="mb-4">Welcome, <?= htmlspecialchars($adminName) ?> (Admin Dashboard)</h3>

    <!-- Alert messages -->
    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <!-- Status Cards -->
    <div class="status-container">
  <div class="status-card all" onclick="filterStatus('All')"><i class="fas fa-list icon"></i><div>All CRs</div><div><?= array_sum($statusCounts) ?></div></div>
  <div class="status-card raised" onclick="filterStatus('Raised')"><i class="fas fa-plus-circle icon"></i><div>Raised</div><div><?= $statusCounts['Raised'] ?></div></div>
  <div class="status-card review" onclick="filterStatus('Under Review')"><i class="fas fa-search icon"></i><div>Under Review</div><div><?= $statusCounts['Under Review'] ?></div></div>
  <div class="status-card assigned" onclick="filterStatus('Assigned')"><i class="fas fa-user-check icon"></i><div>Assigned</div><div><?= $statusCounts['Assigned'] ?></div></div>
  <div class="status-card progress" onclick="filterStatus('In Progress')"><i class="fas fa-spinner fa-spin icon"></i><div>In Progress</div><div><?= $statusCounts['In Progress'] ?></div></div>
  <div class="status-card completed" onclick="filterStatus('Completed')"><i class="fas fa-check icon"></i><div>Completed</div><div><?= $statusCounts['Completed'] ?></div></div>
  <div class="status-card delivered" onclick="filterStatus('Delivered')"><i class="fas fa-box icon"></i><div>Delivered</div><div><?= $statusCounts['Delivered'] ?></div></div>
</div>


    <!-- CR Table -->
    <div class="table-responsive">
      <table class="table table-bordered table-striped" id="crTable">
        <thead class="table-dark">
          <tr>
            <th>CR ID</th>
            <th>Application</th>
            <th>Description</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Developer</th>
            <th>Created On</th>
            <th>Attachment</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($cr = $crList->fetch_assoc()): ?>
          <tr data-status="<?= htmlspecialchars($cr['CR_Status']) ?>">
            <td><?= $cr['CR_ID'] ?></td>
            <td><?= htmlspecialchars($cr['Application_Name']) ?></td>
            <td><?= htmlspecialchars(substr($cr['Project_Description'],0,50)) ?>...</td>
            <td><?= htmlspecialchars($cr['CR_Status']) ?></td>
            <td><?= htmlspecialchars($cr['Priority']) ?></td>
            <td>
            <?php
            if (!empty($cr['DeveloperID'])) {
                echo htmlspecialchars(isset($developers[$cr['DeveloperID']]) ? $developers[$cr['DeveloperID']] : 'Unknown');
            } else {
                echo 'Not Assigned';
            }
            ?>
            </td>
            <td><?= date('Y-m-d', strtotime($cr['Created_On'])) ?></td>
            <td>
              <?php if (!empty($cr['Attachment'])): ?>
                  <a href="<?= htmlspecialchars($cr['Attachment']) ?>" target="_blank" class="btn btn-sm btn-link text-primary">
                      <i class="fas fa-paperclip"></i> View
                  </a>
              <?php else: ?>
                  <span class="text-muted">No Attachment</span>
              <?php endif; ?>
            </td>
            <td>
                <?php if($cr['CR_Status']==='Raised'): ?>
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#assignModal" data-crid="<?= $cr['CR_ID'] ?>">Assign</button>
                    <form method="POST" action="reject_cr.php" style="display:inline;" onsubmit="event.preventDefault(); confirmAction('Are you sure you want to reject this CR?', this);">
                        <input type="hidden" name="cr_id" value="<?= $cr['CR_ID'] ?>">
                        <button type="submit" class="btn btn-sm btn-danger">Reject</button>
                    </form>
                <?php elseif($cr['CR_Status']==='Assigned'): ?>
                    <form method="POST" action="update_status.php" style="display:inline;" onsubmit="event.preventDefault(); confirmAction('Start this CR?', this);">
                        <input type="hidden" name="cr_id" value="<?= $cr['CR_ID'] ?>">
                        <input type="hidden" name="new_status" value="In Progress">
                        <button type="submit" class="btn btn-sm btn-warning">Start</button>
                    </form>
                <?php elseif($cr['CR_Status']==='In Progress'): ?>
                    <form method="POST" action="update_status.php" style="display:inline;" onsubmit="event.preventDefault(); confirmAction('Mark this CR as Completed?', this);">
                        <input type="hidden" name="cr_id" value="<?= $cr['CR_ID'] ?>">
                        <input type="hidden" name="new_status" value="Completed">
                        <button type="submit" class="btn btn-sm btn-success">Complete</button>
                    </form>
                <?php elseif($cr['CR_Status']==='Completed'): ?>
                    <form method="POST" action="update_status.php" style="display:inline;" onsubmit="event.preventDefault(); confirmAction('Deliver this CR?', this);">
                        <input type="hidden" name="cr_id" value="<?= $cr['CR_ID'] ?>">
                        <input type="hidden" name="new_status" value="Delivered">
                        <button type="submit" class="btn btn-sm btn-dark">Deliver</button>
                    </form>
                <?php else: ?>
                    <span class="text-muted">No Action</span>
                <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Assign CR Modal -->
<div class="modal fade" id="assignModal" tabindex="-1" aria-labelledby="assignModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="assign_cr.php" class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="assignModalLabel">Assign CR to Developer</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="cr_id" id="modal_cr_id">
        <div class="mb-3">
          <label for="developer" class="form-label">Select Developer</label>
          <select name="developer_id" id="developer" class="form-select" required>
            <option value="">-- Choose Developer --</option>
            <?php foreach($developers as $id=>$name): ?>
              <option value="<?= htmlspecialchars($id) ?>"><?= htmlspecialchars($name) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="remarks" class="form-label">Remarks</label>
          <textarea name="remarks" id="remarks" class="form-control" rows="3" placeholder="Enter remarks..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Assign</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
  function filterStatus(status) {
  const rows = document.querySelectorAll("#crTable tbody tr");

  rows.forEach(row => {
    if (status === 'All' || row.getAttribute('data-status') === status) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });

  // Highlight the active card
  document.querySelectorAll('.status-card').forEach(card => card.classList.remove('active-card'));
  const activeCard = document.querySelector(`.status-card.${status.toLowerCase().replace(/\s+/g, '')}`) || document.querySelector('.status-card.all');
  if (activeCard) activeCard.classList.add('active-card');
}

function confirmAction(message, form) {
    if(confirm(message)) { form.submit(); }
}

function filterStatus(status) {
    const rows = document.querySelectorAll("#crTable tbody tr");
    rows.forEach(row => row.style.display = (status==='All'||row.getAttribute('data-status')===status)?'':'none');
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
}

// Set CR ID in modal
var assignModal = document.getElementById('assignModal');
assignModal.addEventListener('show.bs.modal', function(event){
    var button = event.relatedTarget;
    var crId = button.getAttribute('data-crid');
    document.getElementById('modal_cr_id').value = crId;
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
