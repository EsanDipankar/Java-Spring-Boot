<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Developer') {
    header("Location: index.php");
    exit();
}

$cr_id = $_POST['cr_id'];
$new_status = $_POST['new_status'];

// Update CR status
$stmt = $conn->prepare("UPDATE cr_datatable SET CR_Status = ? WHERE CR_ID = ?");
$stmt->bind_param("si", $new_status, $cr_id);
if ($stmt->execute()) {
    header("Location: DeveloperDashboard.php");
} else {
    echo "Error updating status.";
}
?>
