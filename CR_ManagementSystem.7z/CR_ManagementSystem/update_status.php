<?php
include 'db.php';
$cr_id = $_POST['cr_id'];
$new_status = $_POST['new_status'];
$conn->query("UPDATE cr_datatable SET CR_Status='$new_status' WHERE CR_ID='$cr_id'");
header("Location: AdminDashboard.php");
exit();
?>
