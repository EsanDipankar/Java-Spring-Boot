<?php
session_start();
include 'db.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['user']);
    $password = trim($_POST['pass']);

    // ✅ Step 1: Basic validation
    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Please enter both username and password.";
        header("Location: admin.php");
        exit();
    }

    // ✅ Step 2: Secure query to prevent SQL injection
    $stmt = $conn->prepare("SELECT AdminID, AdminName, Password, Role FROM Admin WHERE AdminName = ?");
    if (!$stmt) {
        die("Database error: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // ✅ Step 3: Check if admin exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($adminId, $adminName, $hashedPassword, $role);
        $stmt->fetch();

        // ✅ Step 4: Password verification (supports both plain text and hashed)
        if ($password === $hashedPassword || password_verify($password, $hashedPassword)) {
            $_SESSION['admin_id'] = $adminId;
            $_SESSION['admin_name'] = $adminName;
            $_SESSION['role'] = $role;

            header("Location: AdminDashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Invalid username or password.";
            header("Location: admin.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Invalid username or password.";
        header("Location: admin.php");
        exit();
    }

    $stmt->close();
} else {
    header("Location: admin.php");
    exit();
}
?>
