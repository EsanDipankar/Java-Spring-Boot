<?php
session_start();
include 'db.php';

// ✅ Step 1: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];

// ✅ Step 2: Get CR ID from GET or POST
if (isset($_POST['cr_id'])) {
    $cr_id = $_POST['cr_id'];
} elseif (isset($_GET['cr_id'])) {
    $cr_id = $_GET['cr_id'];
} else {
    $cr_id = null;
}
if (isset($_POST['cr_id'])) {
    $cr_id = $_POST['cr_id'];
} elseif (isset($_GET['cr_id'])) {
    $cr_id = $_GET['cr_id'];
} else {
    $cr_id = null;
}

if (!$cr_id) {
    $_SESSION['error'] = "Invalid CR ID.";
    header("Location: UserDashboard.php");
    exit();
}

// ✅ Step 3: Check CR ownership and status
$query = "SELECT Attachment, CR_Status FROM cr_datatable WHERE CR_ID = ? AND UserID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $cr_id, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "CR not found or you don't have permission to delete it.";
    header("Location: UserDashboard.php");
    exit();
}

$cr = $result->fetch_assoc();
$stmt->close();

// ✅ Step 4: Allow delete only if CR is not assigned
if (!in_array($cr['CR_Status'], ['Raised', 'Under Review'])) {
    $_SESSION['error'] = "You can only delete CRs that are not yet assigned.";
    header("Location: UserDashboard.php");
    exit();
}

// ✅ Step 5: Delete CR record
$deleteStmt = $conn->prepare("DELETE FROM cr_datatable WHERE CR_ID = ? AND UserID = ?");
$deleteStmt->bind_param("is", $cr_id, $userId);

if ($deleteStmt->execute()) {
    // ✅ Delete attachment file if exists
    if (!empty($cr['Attachment']) && file_exists($cr['Attachment'])) {
        unlink($cr['Attachment']);
    }
    $_SESSION['success'] = "CR (ID: $cr_id) deleted successfully.";
} else {
    $_SESSION['error'] = "Failed to delete CR. Please try again.";
}

$deleteStmt->close();
$conn->close();

// ✅ Redirect back to user dashboard
header("Location: UserDashboard.php");
exit();
?>
