<?php
session_start();
include 'db.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];

if (isset($_POST['submit'])) {
    $applicationName = $_POST['application_name'];
    $projectDescription = $_POST['project_description'];
    $remarks = $_POST['remarks'];
    $priority = $_POST['priority'];
    $attachmentPath = "";
    $fileValid = true;

    // 🔴 Mandatory file upload check
    if (empty($_FILES['attachment']['name'])) {
        $_SESSION['message'] = "⚠️ Please attach a valid document before submitting.";
        $fileValid = false;
    } else {
        // File upload handling
        $allowedExtensions = ['pdf','doc','docx','ppt','pptx','xls','xlsx','txt','jpg'];
        $maxFileSize = 10 * 1024 * 1024; // 10 MB
        $uploadDir = "uploads/";

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $fileName = basename($_FILES['attachment']['name']);
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $fileSize = $_FILES['attachment']['size'];

        if (!in_array($fileType, $allowedExtensions)) {
            $_SESSION['message'] = "❌ Invalid file type. Allowed: PDF, DOC, PPT, XLS, TXT, JPG";
            $fileValid = false;
        } elseif ($fileSize > $maxFileSize) {
            $_SESSION['message'] = "❌ File size exceeds 10MB limit.";
            $fileValid = false;
        } else {
            $targetFile = $uploadDir . uniqid() . "_" . $fileName;
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $targetFile)) {
                $attachmentPath = $targetFile;
            } else {
                $_SESSION['message'] = "❌ File upload failed!";
                $fileValid = false;
            }
        }
    }

    // ✅ Only insert CR if all fields valid including attachment
    if ($fileValid && !empty($applicationName) && !empty($projectDescription)) {
        $stmt = $conn->prepare("
            INSERT INTO CR_DataTable 
            (UserID, Application_Name, Project_Description, Remarks, Priority, CR_Status, Attachment)
            VALUES (?, ?, ?, ?, ?, 'Raised', ?)
        ");
        $stmt->bind_param("ssssss", $userId, $applicationName, $projectDescription, $remarks, $priority, $attachmentPath);

        if ($stmt->execute()) {
            $_SESSION['message'] = "✅ Change Request raised successfully with attachment!";
        } else {
            $_SESSION['message'] = "❌ Database Error: " . $conn->error;
        }
        $stmt->close();
    } elseif (!$fileValid) {
        // Already handled above
    } else {
        $_SESSION['message'] = "⚠️ Please fill all required fields!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Raise Change Request</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body { background-color: #f4f6f9; }
    .container { max-width: 700px; margin-top: 50px; }
    .card { border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .required::after { content:" *"; color:red; }
    .file-info { font-size: 0.9em; color: #555; margin-top: 3px; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary p-3">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="UserDashboard.php">CR Management System</a>

    <div class="ms-auto d-flex align-items-center">
      <!-- Home Button -->
      <a href="UserDashboard.php" class="btn btn-light btn-sm me-3">
        <i class="fa fa-home"></i> Home
      </a>

      <div class="text-white">
        <i class="fa fa-user"></i> <?= htmlspecialchars($userName) ?> |
        <a href="logout.php" class="text-white ms-2">Logout</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card p-4">
    <h3 class="text-center mb-4 text-primary"><i class="fa fa-upload"></i> Raise a Change Request</h3>

    <?php if (isset($_SESSION['message'])): ?>
      <div class="alert alert-info alert-dismissible fade show">
        <?= $_SESSION['message']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
      <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">

      <div class="mb-3">
        <label for="application_name" class="form-label required">Application Name</label>
        <select name="application_name" id="application_name" class="form-select" required>
          <option value="">-- Select Application --</option>
          <option value="CloudConversion">CloudConversion</option>
          <option value="Digiview">Digiview</option>
          <option value="YouCalc">YouCalc</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="project_description" class="form-label required">CR Description</label>
        <textarea name="project_description" id="project_description" class="form-control" rows="4" placeholder="Enter the project details..." required></textarea>
      </div>

      <div class="mb-3">
        <label for="remarks" class="form-label">Remarks (Optional)</label>
        <textarea name="remarks" id="remarks" class="form-control" rows="2" placeholder="Any additional remarks..."></textarea>
      </div>
      <div class="mb-3">
        <label for="priority" class="form-label required">Priority</label>
        <select name="priority" id="priority" class="form-select" required>
          <option value="">-- Select Priority --</option>
          <option value="Low">Low</option>
          <option value="Medium" >Medium</option>
          <option value="High" selected>High</option>
          <option value="Critical">Critical</option>
        </select>
      </div>
        <div class="mb-3">
          <label for="attachment" class="form-label required">Attach Document</label>
          <input type="file" name="attachment" id="attachment" class="form-control"
                accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.jpg" required>
          <div class="file-info">Allowed types: PDF, DOC, PPT, XLS, TXT, JPG | Max size: 10MB</div>
        </div>
      <div class="text-center mt-4">
        <button type="submit" name="submit" class="btn btn-primary px-4">
          <i class="fa fa-paper-plane"></i> Submit CR
        </button>
        <a href="UserDashboard.php" class="btn btn-secondary px-4 ms-2">
        <i class="fa fa-times"></i> Cancel
        </a>
      </div>
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>