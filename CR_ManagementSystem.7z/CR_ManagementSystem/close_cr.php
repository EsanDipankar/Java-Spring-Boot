<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id'])) { 
    header("Location:index.php"); 
    exit(); 
}

$userId = $_SESSION['user_id'];

// Accept data from either POST or GET (compatible with older PHP)
$cr_id = isset($_POST['cr_id']) ? $_POST['cr_id'] : (isset($_GET['cr_id']) ? $_GET['cr_id'] : null);
$action = isset($_POST['action_type']) ? $_POST['action_type'] : (isset($_GET['action']) ? $_GET['action'] : null);
$remarks = isset($_POST['remarks']) ? $_POST['remarks'] : (isset($_GET['remarks']) ? $_GET['remarks'] : null);

if (!$cr_id || !$action || !$remarks) {
    die("Invalid request — missing parameters.");
}

// Determine new status based on action
if ($action === 'accept') {
    $newStatus = 'Closed';
} elseif ($action === 'reject') {
    $newStatus = 'Delivered Rejected';
} else {
    die("Invalid action.");
}

// Update CR record
$stmt = $conn->prepare("UPDATE cr_datatable 
                        SET CR_Status = ?, Remarks = ? 
                        WHERE CR_ID = ? AND UserID = ? AND CR_Status = 'Delivered'");
$stmt->bind_param("ssss", $newStatus, $remarks, $cr_id, $userId);
$stmt->execute();
$stmt->close();
$conn->close();

// Redirect with success message
header("Location: userDashboard.php?msg=success");
exit();
?>
