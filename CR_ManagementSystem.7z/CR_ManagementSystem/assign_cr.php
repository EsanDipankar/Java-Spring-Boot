<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cr_id = $_POST['cr_id'];
    $developer_id = $_POST['developer_id'];
    $remarks = $_POST['remarks'];

    if (empty($cr_id) || empty($developer_id)) {
        $_SESSION['error'] = "CR ID or Developer ID missing.";
        header("Location: AdminDashboard.php");
        exit();
    }

    $stmt = $conn->prepare("UPDATE cr_datatable SET DeveloperID=?, CR_Status='Assigned', Remarks=? WHERE CR_ID=?");
    $stmt->bind_param("ssi", $developer_id, $remarks, $cr_id);
    $stmt->execute();

    $stmt->close();
    $conn->close();

    $_SESSION['success'] = "CR successfully assigned!";
    header("Location: AdminDashboard.php");
    exit();
}

?>
