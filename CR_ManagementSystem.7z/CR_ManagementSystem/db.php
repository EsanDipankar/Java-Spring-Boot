<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "admin123"; // your MySQL root password
$dbname = "CrManagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection failed: " . $conn->connect_error);
}

// Optional: set character encoding
$conn->set_charset("utf8");
?>
