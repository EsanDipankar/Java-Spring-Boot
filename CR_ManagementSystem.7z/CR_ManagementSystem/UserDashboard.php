<?php
session_start();
include 'db.php'; // Ensure db.php creates $conn = new mysqli(...)

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['UserName'];

// --------------- Status Summary Query ----------------
$statusQuery = "SELECT CR_Status, COUNT(*) AS Count FROM cr_datatable WHERE UserID = ? GROUP BY CR_Status";
$stmt = $conn->prepare($statusQuery);
$stmt->bind_param("s", $userId);
$stmt->execute();
$statusResult = $stmt->get_result();

$statusCounts = [
    'Raised' => 0,
    'Under Review' => 0,
    'Assigned' => 0,
    'In Progress' => 0,
    'Completed' => 0,
    'Delivered' => 0,
    'Closed' => 0
];

while ($row = $statusResult->fetch_assoc()) {
    $statusCounts[$row['CR_Status']] = $row['Count'];
}
$stmt->close();

// --------------- CR Details Table ----------------
$query = "SELECT c.CR_ID, c.Application_Name, c.Project_Description, c.CR_Status, 
                 d.DeveloperName, c.Created_On, c.Attachment
          FROM cr_datatable c 
          LEFT JOIN developers d ON c.DeveloperID = d.DeveloperID 
          WHERE c.UserID = ?
          ORDER BY c.Created_On DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$result = $stmt->get_result();

$crData = [];
while ($row = $result->fetch_assoc()) {
    $crData[] = $row;
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
body { margin:0; padding:0; font-family: 'Segoe UI', sans-serif; background-color: #f4f6f9; }
.wrapper { display: flex; min-height: 100vh; }
#sidebar { width: 220px; background: #2f3640; color: #fff; transition: width 0.3s ease; }
#sidebar.collapsed { width: 60px; }
#sidebar .nav-link { color: #fff; display: flex; align-items: center; gap: 10px; padding: 12px; }
#sidebar .nav-link:hover { background: #353b48; }
#sidebar.collapsed .nav-link span { display: none; }
.content { flex: 1; padding: 20px; }

.status-container { display: flex; flex-wrap: wrap; gap: 10px; justify-content: space-around; margin-bottom: 20px; }
.status-card { flex: 1; max-width: 160px; min-width: 140px; min-height: 130px; border-radius: 10px; color: white; padding: 15px; text-align: center; cursor: pointer; display: flex; flex-direction: column; justify-content: center; align-items: center; }
.status-card .icon { font-size: 36px; margin-bottom: 8px; }
.raised { background-color: #007bff; }
.review { background-color: #6f42c1; }
.assigned { background-color: #ffc107; color: black; }
.progress { background-color: #17a2b8; }
.completed { background-color: #28a745; }
.delivered { background-color: #20c997; }
.closed { background-color: #dc3545; }

table { background-color: white; border-radius: 10px; overflow: hidden; }
th { background-color: #343a40; color: white; text-align: center; }
td, th { text-align: center; vertical-align: middle; }

.raise-btn { background-color: #007bff; color: white; font-weight: bold; border: none; padding: 8px 16px; border-radius: 8px; }
.raise-btn:hover { background-color: #0056b3; }
.all { background-color: #495057; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- Sidebar -->
  <nav id="sidebar">
    <button id="toggle-btn" class="btn btn-link text-white mt-2" onclick="toggleSidebar()">☰</button>
    <h5 class="text-center mt-3">User Menu</h5>
    <ul class="nav flex-column mt-3">
      <li><a href="UserDashboard.php" class="nav-link"><i class="fa fa-home"></i><span> Home</span></a></li>
      <li><a href="raise_cr.php" class="nav-link"><i class="fa fa-upload"></i><span> Raise CR</span></a></li>
      <li><a href="logout.php" class="nav-link"><i class="fa fa-sign-out-alt"></i><span> Logout</span></a></li>
    </ul>
  </nav>

  <!-- Content -->
  <div class="content">
    <h3 class="mb-4">Welcome, <?= htmlspecialchars($userName) ?> (User Dashboard)</h3>

    <!-- Status Cards -->
    <div class="status-container">
  <div class="status-card all" onclick="filterStatus('')"><i class="fas fa-list icon"></i>All CRs<br><?= array_sum($statusCounts) ?></div>
  <div class="status-card raised" onclick="filterStatus('Raised')"><i class="fas fa-plus-circle icon"></i>Raised<br><?= $statusCounts['Raised'] ?></div>
  <div class="status-card review" onclick="filterStatus('Under Review')"><i class="fas fa-search icon"></i>Under Review<br><?= $statusCounts['Under Review'] ?></div>
  <div class="status-card assigned" onclick="filterStatus('Assigned')"><i class="fas fa-user-check icon"></i>Assigned<br><?= $statusCounts['Assigned'] ?></div>
  <div class="status-card progress" onclick="filterStatus('In Progress')"><i class="fas fa-spinner icon"></i>In Progress<br><?= $statusCounts['In Progress'] ?></div>
  <div class="status-card completed" onclick="filterStatus('Completed')"><i class="fas fa-check-circle icon"></i>Completed<br><?= $statusCounts['Completed'] ?></div>
  <div class="status-card delivered" onclick="filterStatus('Delivered')"><i class="fas fa-truck icon"></i>Delivered<br><?= $statusCounts['Delivered'] ?></div>
  <div class="status-card closed" onclick="filterStatus('Closed')"><i class="fas fa-lock icon"></i>Closed<br><?= $statusCounts['Closed'] ?></div>
</div>


    <!-- CR Table -->
    <div class="mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5>My CRs</h5>
            <button class="raise-btn" onclick="location.href='raise_cr.php'">+ Raise New CR</button>
        </div>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>CR ID</th>
                    <th>Application Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Developer Name</th>
                    <th>Created On</th>
                    <th>Attachment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="crTable">
                <?php if (count($crData) > 0): ?>
                    <?php foreach ($crData as $cr): ?>
                        <tr data-status="<?= htmlspecialchars($cr['CR_Status']) ?>">
                            <td><?= htmlspecialchars($cr['CR_ID']) ?></td>
                            <td><?= htmlspecialchars($cr['Application_Name']) ?></td>
                            <td><?= htmlspecialchars($cr['Project_Description']) ?></td>
                            <td><?= htmlspecialchars($cr['CR_Status']) ?></td>
                            <td><?= htmlspecialchars(!empty($cr['DeveloperName']) ? $cr['DeveloperName'] : 'Not Assigned') ?></td>
                            <td><?= date('Y-m-d', strtotime($cr['Created_On'])) ?></td>
                            <td>
                                <?php if (!empty($cr['Attachment'])): ?>
                                    <a href="<?= htmlspecialchars($cr['Attachment']) ?>" target="_blank" class="btn btn-sm btn-link text-primary">
                                        View / Download
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">No Attachment</span>
                                <?php endif; ?>
                                </td>
                            <td>
                                <?php if (in_array($cr['CR_Status'], ['Raised', 'Under Review'])): ?>
                                <form method="POST" action="delete_cr.php" style="display:inline;" 
                                    onsubmit="return confirm('Are you sure you want to delete this CR?');">
                                    <input type="hidden" name="cr_id" value="<?= $cr['CR_ID'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fa fa-trash"></i> Delete</button>
                                </form>
                                    <?php elseif ($cr['CR_Status'] === 'Delivered'): ?>
                                    <button class="btn btn-success btn-sm" onclick="closeCR('<?= $cr['CR_ID'] ?>','accept')">Accept</button>
                                    <button class="btn btn-warning btn-sm" onclick="closeCR('<?= $cr['CR_ID'] ?>','reject')">Reject</button>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8">No CR records found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
}

function filterStatus(status) {
    const rows = document.querySelectorAll("#crTable tr");
    rows.forEach(row => {
        row.style.display = (row.dataset.status === status || status === '') ? '' : 'none';
    });
}

function filterStatus(status) {
    const rows = document.querySelectorAll("#crTable tr");
    rows.forEach(row => {
        row.style.display = (row.dataset.status === status || status === '') ? '' : 'none';
    });
}

// 🗑️ Delete Confirmation (Modern SweetAlert)
function deleteCR(crId) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This CR will be permanently deleted!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        background: '#fefefe',
        backdrop: true
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Deleting...',
                text: 'Please wait while we remove the CR.',
                icon: 'info',
                showConfirmButton: false,
                allowOutsideClick: false,
                timer: 1000
            }).then(() => {
                window.location.href = 'delete_cr.php?cr_id=' + crId;
            });
        }
    });
}

// ✅ Accept/Reject CR (with Remarks)
function closeCR(crId, action) {
    Swal.fire({
        title: `${action === 'accept' ? 'Accept' : 'Reject'} CR`,
        input: 'textarea',
        inputPlaceholder: 'Enter your remarks...',
        inputAttributes: { 'aria-label': 'Enter your remarks here' },
        showCancelButton: true,
        confirmButtonText: `Confirm ${action}`,
        cancelButtonText: 'Cancel',
        confirmButtonColor: action === 'accept' ? '#28a745' : '#ffc107',
        cancelButtonColor: '#6c757d',
        background: '#fefefe',
        preConfirm: (remarks) => {
            if (!remarks || remarks.trim() === '') {
                Swal.showValidationMessage('Remarks are required!');
            } else {
                return remarks.trim();
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Processing...',
                text: `Submitting your ${action} response.`,
                icon: 'info',
                showConfirmButton: false,
                allowOutsideClick: false,
                timer: 1000
            }).then(() => {
                const remarks = encodeURIComponent(result.value);
                window.location.href = `close_cr.php?cr_id=${crId}&action=${action}&remarks=${remarks}`;
            });
        }
    });
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
