<?php
session_start();
include 'db.php';

// Check developer access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Developer') {
    header("Location: index.php");
    exit();
}

$developerId = $_SESSION['developer_id'];
$developerName = $_SESSION['developer_name'];

// Initialize status counts
$statusCounts = [
    "All" => 0,
    "Assigned" => 0,
    "In Progress" => 0,
    "Completed" => 0,
    "Delivered" => 0
];

// Fetch total CR count for this developer
$totalQuery = "SELECT COUNT(*) AS total FROM cr_datatable WHERE DeveloperID = ?";
$stmt = $conn->prepare($totalQuery);
$stmt->bind_param("i", $developerId);
$stmt->execute();
$totalResult = $stmt->get_result();
if ($row = $totalResult->fetch_assoc()) {
    $statusCounts["All"] = $row["total"];
}

// Fetch status counts for this developer
$statusQuery = "SELECT CR_Status, COUNT(*) AS count FROM cr_datatable 
                WHERE DeveloperID = ? GROUP BY CR_Status";
$stmt = $conn->prepare($statusQuery);
$stmt->bind_param("i", $developerId);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $statusCounts[$row['CR_Status']] = $row['count'];
}

// Fetch all CRs assigned to this developer
$query = "SELECT * FROM cr_datatable WHERE DeveloperID = ? ORDER BY Created_On DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $developerId);
$stmt->execute();
$crList = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Developer Dashboard - CR Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
body { margin: 0; padding: 0; background-color: #f5f6fa; }
.wrapper { display: flex; min-height: 100vh; }
#sidebar { width: 240px; background: #2f3640; color: #fff; transition: width 0.3s ease; }
#sidebar.collapsed { width: 60px; }
#sidebar .nav-link { color: #fff; display: flex; align-items: center; gap: 10px; padding: 12px; }
#sidebar .nav-link:hover { background: #353b48; }
#sidebar.collapsed .nav-link span { display: none; }
.content { flex: 1; padding: 20px; }
.status-container { display: flex; flex-wrap: wrap; gap: 10px; justify-content: space-around; margin-bottom: 20px; }
.status-card {
    flex: 1;
    max-width: 180px;
    min-width: 140px;
    min-height: 130px;
    border-radius: 10px;
    color: white;
    padding: 15px;
    text-align: center;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.status-card:hover { transform: scale(1.05); }
.status-card .icon { font-size: 36px; margin-bottom: 8px; }
.status-card.all { background-color: #00a8ff; }
.status-card.assigned { background-color: #fbc531; color: black; }
.status-card.progress { background-color: #e1b12c; color: black; }
.status-card.completed { background-color: #4cd137; }
.status-card.delivered { background-color: #44bd32; }
table { background: white; border-radius: 8px; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- Sidebar -->
  <nav id="sidebar">
    <button id="toggle-btn" class="btn btn-link text-white mt-2" onclick="toggleSidebar()">☰</button>
    <h5 class="text-center mt-3">Developer Menu</h5>
    <ul class="nav flex-column mt-3">
      <li><a href="DeveloperDashboard.php" class="nav-link"><i class="fa fa-home"></i><span> Home</span></a></li>
      <li><a href="logout.php" class="nav-link"><i class="fa fa-sign-out-alt"></i><span> Logout</span></a></li>
    </ul>
  </nav>

  <!-- Content -->
  <div class="content">
    <h3 class="mb-4">Welcome, <?= htmlspecialchars($developerName) ?> (Developer Dashboard)</h3>

    <!-- Status Cards -->
    <div class="status-container">
      <div class="status-card all" onclick="filterStatus('All')">
        <i class="fas fa-layer-group icon"></i>
        <div>All CR</div>
        <div><?= $statusCounts['All'] ?></div>
      </div>
      <div class="status-card assigned" onclick="filterStatus('Assigned')">
        <i class="fas fa-user-check icon"></i>
        <div>Assigned</div>
        <div><?= $statusCounts['Assigned'] ?></div>
      </div>
      <div class="status-card progress" onclick="filterStatus('In Progress')">
        <i class="fas fa-spinner fa-spin icon"></i>
        <div>In Progress</div>
        <div><?= $statusCounts['In Progress'] ?></div>
      </div>
      <div class="status-card completed" onclick="filterStatus('Completed')">
        <i class="fas fa-check icon"></i>
        <div>Completed</div>
        <div><?= $statusCounts['Completed'] ?></div>
      </div>
      <div class="status-card delivered" onclick="filterStatus('Delivered')">
        <i class="fas fa-box icon"></i>
        <div>Delivered</div>
        <div><?= $statusCounts['Delivered'] ?></div>
      </div>
    </div>

    <!-- CR Table -->
    <div class="table-responsive">
      <table class="table table-bordered table-striped" id="crTable">
        <thead class="table-dark">
          <tr>
            <th>CR ID</th>
            <th>Application</th>
            <th>Description</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Attachment</th>
            <th>Created On</th>
            <th>Attachment</th> 
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($cr = $crList->fetch_assoc()) { ?>
          <tr data-status="<?= htmlspecialchars($cr['CR_Status']) ?>">
            <td><?= $cr['CR_ID'] ?></td>
            <td><?= htmlspecialchars($cr['Application_Name']) ?></td>
            <td><?= htmlspecialchars(substr($cr['Project_Description'], 0, 50)) ?>...</td>
            <td><?= htmlspecialchars($cr['CR_Status']) ?></td>
            <td><?= htmlspecialchars($cr['Priority']) ?></td>
            <td>
              <?php if (!empty($cr['Attachment_Path'])) { ?>
                <a href="<?= htmlspecialchars($cr['Attachment_Path']) ?>" class="btn btn-sm btn-outline-primary" download>Download</a>
              <?php } else { ?>
                <span class="text-muted">No File</span>
              <?php } ?>
            </td>
            <td><?= date('Y-m-d', strtotime($cr['Created_On'])) ?></td>
            <td>
            <?php if (!empty($cr['Attachment'])): ?>
                <a href="<?= htmlspecialchars($cr['Attachment']) ?>" target="_blank" class="btn btn-sm btn-link text-primary">
                    View / Download
                </a>
            <?php else: ?>
                <span class="text-muted">No Attachment</span>
            <?php endif; ?>
            </td>
            <td>
              <?php if ($cr['CR_Status'] === 'Assigned') { ?>
                <button class="btn btn-sm btn-success" onclick="confirmAction('accept', <?= $cr['CR_ID'] ?>)">Accept</button>
                <button class="btn btn-sm btn-danger" onclick="rejectCR(<?= $cr['CR_ID'] ?>)">Reject</button>
              <?php } elseif ($cr['CR_Status'] === 'In Progress') { ?>
                <button class="btn btn-sm btn-primary" onclick="confirmAction('complete', <?= $cr['CR_ID'] ?>)">Mark Complete</button>
              <?php } else { ?>
                <span class="text-muted">No Action</span>
              <?php } ?>
            </td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('collapsed');
}

function filterStatus(status) {
  const rows = document.querySelectorAll("#crTable tbody tr");
  rows.forEach(row => {
    row.style.display = (status === 'All' || row.getAttribute("data-status") === status) ? "" : "none";
  });
}

function rejectCR(crId) {
    Swal.fire({
        title: 'Reject CR?',
        text: "This will revert the CR to 'Raised' state for admin reassignment!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, reject'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `revert_cr.php?cr_id=${crId}`;
        }
    });
}



function confirmAction(action, crId) {
  let title = '', text = '', newStatus = '';
  if (action === 'accept') {
    title = 'Accept this CR?';
    text = 'Once accepted, this CR will move to In Progress.';
    newStatus = 'In Progress';
  } else if (action === 'reject') {
    title = 'Reject this CR?';
    text = 'Are you sure you want to reject this CR?';
    newStatus = 'Rejected';
  } else if (action === 'complete') {
    title = 'Mark CR as Completed?';
    text = 'Confirm completion of this CR.';
    newStatus = 'Completed';
  }

  Swal.fire({
    title: title,
    text: text,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, confirm!'
  }).then((result) => {
    if (result.isConfirmed) {
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = 'update_status_developer.php';
      form.innerHTML = `
        <input type="hidden" name="cr_id" value="${crId}">
        <input type="hidden" name="new_status" value="${newStatus}">
      `;
      document.body.appendChild(form);
      form.submit();
    }
  });
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
