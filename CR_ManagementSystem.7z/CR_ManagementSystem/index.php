<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Login</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    body {
      background-color: #61869a;
    }

    .card {
      border-radius: 1rem;
      overflow: hidden;
    }

    .form-label {
      text-transform: capitalize;
    }
  </style>
</head>

<body>

  <section class="vh-100">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col col-xl-10">
          <div class="card shadow-lg">
            <div class="row g-0">
              <!-- Left image -->
              <div class="col-md-6 col-lg-5 d-none d-md-block">
                <img src="https://i.pinimg.com/564x/44/2d/00/442d001d35e56f543ccc09f84154e2f0.jpg"
                  alt="login form" class="img-fluid h-100" style="object-fit: cover;" />
              </div>

              <!-- Right form -->
              <div class="col-md-6 col-lg-7 d-flex align-items-center">
                <div class="card-body p-4 p-lg-5 text-black">

                  <form action="login.php" method="post">
                    <div class="d-flex align-items-center mb-3 pb-1">
                      <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                      <span class="h3 fw-bold mb-0">CR Management System</span>
                    </div>

                    <h5 class="fw-normal mb-3 pb-3 text-danger" style="letter-spacing: 1px;">User Login</h5>

                    <div class="form-outline mb-4">
                      <input type="text" id="username" class="form-control form-control-lg" name="user" required />
                      <label class="form-label" for="username">Username</label>
                    </div>

                    <div class="form-outline mb-4">
                      <input type="password" id="password" class="form-control form-control-lg" name="pass" required />
                      <label class="form-label" for="password">Password</label>

                      <?php
                      if (isset($_SESSION['error'])) {
                        echo "<p class='text-warning mt-2'>" . htmlspecialchars($_SESSION['error']) . "</p>";
                        unset($_SESSION['error']);
                      }
                      ?>
                    </div>

                    <div class="pt-1 mb-4">
                      <input class="btn btn-primary btn-lg btn-block w-100" type="submit" value="Login" />
                    </div>

                    <div class="text-center">
                      <a href="admin.php" class="text-decoration-none text-success fw-semibold">
                        Click here for Admin Login
                      </a>
                    </div>
                    <div class="text-center">
                      <a href="developer.php" class="text-decoration-none text-success fw-semibold">
                        Click here for Developer Login
                      </a>
                    </div>
                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
    crossorigin="anonymous"></script>
</body>

</html>
