<?php
session_start();
include 'db.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'Developer') {
    header("Location: index.php");
    exit();
}

$cr_id = isset($_GET['cr_id']) ? $_GET['cr_id'] : null;
$developerId = $_SESSION['developer_id'];

if($cr_id) {
    $stmt = $conn->prepare("
        UPDATE cr_datatable 
        SET CR_Status='Raised', DeveloperID=NULL 
        WHERE CR_ID=? AND DeveloperID=?
    ");

    if(!$stmt) {
        die("Prepare failed: " . $conn->error); // <-- This will show the SQL error
    }

    $stmt->bind_param("ii", $cr_id, $developerId);
    $stmt->execute();

    if($stmt->affected_rows > 0){
        $_SESSION['success'] = "CR has been reverted to 'Raised' state.";
    } else {
        $_SESSION['error'] = "Failed to revert CR. It may not be assigned to you.";
    }

    $stmt->close();
    $conn->close();

    header("Location: DeveloperDashboard.php");
    exit();
} else {
    $_SESSION['error'] = "Invalid CR ID!";
    header("Location: DeveloperDashboard.php");
    exit();
}
?>
