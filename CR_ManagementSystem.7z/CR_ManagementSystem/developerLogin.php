<?php
session_start();
include 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['user']);
    $password = trim($_POST['pass']);

    // Step 1: Basic validation
    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Please enter both username and password.";
        header("Location: developer.php");
        exit();
    }

    // Step 2: Secure query
    $stmt = $conn->prepare("SELECT DeveloperID, DeveloperName, Password FROM developers WHERE DeveloperName = ?");
    if (!$stmt) {
        die("Database error: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Step 3: Check developer record
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($devId, $devName, $hashedPassword);
        $stmt->fetch();

        // Step 4: Verify password (plain or hashed)
        if ($password === $hashedPassword || password_verify($password, $hashedPassword)) {
            $_SESSION['developer_id'] = $devId;
            $_SESSION['developer_name'] = $devName;
            $_SESSION['role'] = 'Developer';

            header("Location: DeveloperDashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Invalid username or password.";
            header("Location: developer.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Invalid username or password.";
        header("Location: developer.php");
        exit();
    }

    $stmt->close();
} else {
    header("Location: developer.php");
    exit();
}
?>
