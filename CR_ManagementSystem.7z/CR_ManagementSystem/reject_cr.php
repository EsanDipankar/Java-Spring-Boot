<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cr_id = $_POST['cr_id'];

    if (empty($cr_id)) {
        die("CR ID missing");
    }

    $stmt = $conn->prepare("UPDATE cr_datatable SET CR_Status='Under Review' WHERE CR_ID=?");
    $stmt->bind_param("i", $cr_id);
    $stmt->execute();

    $stmt->close();
    $conn->close();

    header("Location: AdminDashboard.php");
    exit();
}
?>