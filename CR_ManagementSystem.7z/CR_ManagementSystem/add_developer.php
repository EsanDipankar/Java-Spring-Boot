<?php
session_start();
include 'db.php';

// ✅ Restrict access to admins only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: index.php");
    exit();
}

// ✅ Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $devId = 'DEV' . uniqid(); // Auto-generate unique DeveloperID
    $name = trim($_POST['developer_name']);
    $email = trim($_POST['developer_email']);
    $skillset = trim($_POST['skillset']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt password
    $status = 'Available';

    $stmt = $conn->prepare("INSERT INTO developers (DeveloperID, DeveloperName, DeveloperEmail, Skillset, Current_Status, Password) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $devId, $name, $email, $skillset, $status, $password);

    if ($stmt->execute()) {
        $_SESSION['success'] = "✅ Developer added successfully!";
    } else {
        $_SESSION['error'] = "❌ Error: " . $stmt->error;
    }
    header("Location: add_developer.php");
    exit();
}

// ✅ Fetch existing developers for display
$result = $conn->query("SELECT DeveloperID, DeveloperName, DeveloperEmail, Skillset, Current_Status, Created_On FROM developers ORDER BY Created_On DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Developer - CR Management System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
<div class="container">
  <h3 class="mb-4">👤 Add New Developer</h3>

  <!-- Alerts -->
  <?php if(isset($_SESSION['success'])): ?>
      <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
  <?php endif; ?>
  <?php if(isset($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>

  <!-- Add Developer Form -->
  <div class="card mb-4">
    <div class="card-body">
      <form method="POST">
        <div class="row mb-3">
          <div class="col-md-6">
            <label for="developer_name" class="form-label">Full Name</label>
            <input type="text" name="developer_name" id="developer_name" class="form-control" required>
          </div>
          <div class="col-md-6">
            <label for="developer_email" class="form-label">Email</label>
            <input type="email" name="developer_email" id="developer_email" class="form-control" required>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col-md-6">
            <label for="skillset" class="form-label">Skillset</label>
            <input type="text" name="skillset" id="skillset" class="form-control" placeholder="e.g. php, SQL, VB.net ">
          </div>
          <div class="col-md-6">
            <label for="password" class="form-label">Temporary Password</label>
            <input type="password" name="password" id="password" class="form-control" required>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Add Developer</button>
        <a href="AdminDashboard.php" class="btn btn-secondary">Back</a>
      </form>
    </div>
  </div>

  <!-- Developer List -->
  <h5 class="mb-3">📋 Existing Developers</h5>
  <div class="table-responsive">
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>Developer ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Skillset</th>
          <th>Status</th>
          <th>Created On</th>
        </tr>
      </thead>
      <tbody>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['DeveloperID']) ?></td>
          <td><?= htmlspecialchars($row['DeveloperName']) ?></td>
          <td><?= htmlspecialchars($row['DeveloperEmail']) ?></td>
          <td><?= htmlspecialchars($row['Skillset']) ?></td>
          <td><?= htmlspecialchars($row['Current_Status']) ?></td>
          <td><?= htmlspecialchars($row['Created_On']) ?></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
