<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<section class="vh-100" style="background-color: #61869a;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col col-xl-10">
                <div class="card" style="border-radius: 1rem;">
                    <div class="row g-0">
                        <div class="col-md-6 col-lg-5 d-none d-md-block">
                            <img src="https://i.pinimg.com/564x/44/2d/00/442d001d35e56f543ccc09f84154e2f0.jpg"
                                 alt="login form" class="img-fluid" style="border-radius: 1rem 0 0 1rem;" />
                        </div>
                        <div class="col-md-6 col-lg-7 d-flex align-items-center">
                            <div class="card-body p-4 p-lg-5 text-black">

                                <form action="developerLogin.php" method="post">
                                    <div class="d-flex align-items-center mb-3 pb-1">
                                        <span class="h1 fw-bold mb-0">CR Management System</span>
                                    </div>

                                    <h5 class="fw-normal mb-3 pb-3 text-primary" style="letter-spacing: 1px;">Developer Login</h5>

                                    <div class="form-outline mb-4">
                                        <input type="text" name="user" class="form-control form-control-lg" required />
                                        <label class="form-label">Username</label>
                                    </div>

                                    <div class="form-outline mb-4">
                                        <input type="password" name="pass" class="form-control form-control-lg" required />
                                        <label class="form-label">Password</label>
                                    </div>

                                    <?php
                                    if (isset($_SESSION['error'])) {
                                        echo "<p class='text-danger fw-bold'>" . htmlspecialchars($_SESSION['error']) . "</p>";
                                        unset($_SESSION['error']);
                                    }
                                    ?>

                                    <div class="pt-1 mb-4">
                                        <button class="btn btn-primary btn-lg btn-block w-100" type="submit">Login</button>
                                    </div>
                                    <div class="text-center">
                                    <a href="index.php" class="text-decoration-none text-success fw-semibold">
                                        Click here for user Login
                                    </a>
                                    </div>
                                    <div class="text-center">
                                    <a href="admin.php" class="text-decoration-none text-success fw-semibold">
                                        Click here for Admin Login
                                    </a>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>
