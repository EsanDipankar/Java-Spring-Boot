<?php
session_start();
include 'db.php'; // Make sure this connects to your MySQL database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['user']);
    $password = trim($_POST['pass']);

    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Please enter username and password.";
        header("Location: index.php");
        exit();
    }

    // Fetch user from database
    $stmt = $conn->prepare("SELECT UserID, UserName, Password FROM Users WHERE UserName = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Assuming password stored as MD5
        if ($user['Password'] === md5($password)) {
            // Login successful
            $_SESSION['user_id'] = $user['UserID'];   // Use this in raise_CR.php
            $_SESSION['user_name'] = $user['UserName'];
            header("Location: UserDashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Incorrect password.";
            header("Location: index.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "User not found.";
        header("Location: index.php");
        exit();
    }
    echo( $_SESSION['error']);
} else {
    // If someone accesses login.php directly
    header("Location: index.php");
    exit();
}
?>
