package com.example.TestDemoApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = TestDemoApplication.class)
public class TestDemoApplicationTests {

    void contextLoads() {
    }
}
