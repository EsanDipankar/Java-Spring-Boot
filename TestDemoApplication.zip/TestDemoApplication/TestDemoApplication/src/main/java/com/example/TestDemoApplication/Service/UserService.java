package com.example.TestDemoApplication.Service;

import com.example.TestDemoApplication.DTO.UserRegisterDTO;
import com.example.TestDemoApplication.Entity.User;
import com.example.TestDemoApplication.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public boolean validateUser(String userId, String rawPassword) {
        User user= userRepository.findByuserId(userId);
        if(user== null) return false;
        return passwordEncoder.matches(rawPassword,user.getPassword());
    }
    public boolean registerUser(UserRegisterDTO dto){
        User existingUser=userRepository.findByuserId(dto.getUserId());
        if(existingUser!= null){
            return false;
        }
        User user= new User();
        user.setUserId(dto.getUserId());
        user.setUsName(dto.getUsName());
        user.setRole(dto.getRole());
        String encryptedPassword= passwordEncoder.encode(dto.getPassword());
        user.setPassword(encryptedPassword);
        userRepository.save(user);
        return  true;
    }
}
