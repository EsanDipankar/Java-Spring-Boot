package com.example.TestDemoApplication.Controller;

import com.example.TestDemoApplication.DTO.UserRegisterDTO;
import com.example.TestDemoApplication.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService userService;
    @PostMapping("/validate")
    public String validateUser(@RequestParam String userId, @RequestParam String password){
        boolean isvalid= userService.validateUser(userId, password);
        return isvalid ?"Valid User": "Invalid Credential";

    }
    @PostMapping("/UserRegister")
    public String userRegister(@RequestBody UserRegisterDTO dto){
        boolean result= userService.registerUser(dto);
        return result ? "User Registered Successfully": "User Already Exist";
    }
}
