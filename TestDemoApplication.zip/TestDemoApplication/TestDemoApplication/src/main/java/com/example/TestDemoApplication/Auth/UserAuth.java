package com.example.TestDemoApplication.Auth;

public class UserAuth {

}
