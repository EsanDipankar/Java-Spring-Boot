package com.example.CRManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
