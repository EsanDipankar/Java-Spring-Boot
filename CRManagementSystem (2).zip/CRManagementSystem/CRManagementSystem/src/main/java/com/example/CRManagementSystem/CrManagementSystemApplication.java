package com.example.CRManagementSystem;

import com.example.CRManagementSystem.model.User;
import com.example.CRManagementSystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrManagementSystemApplication implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(CrManagementSystemApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Test saving a user
		User testUser = new User("dipankar", "12345", "USER");
		userRepository.save(testUser);

		// Fetch all users
		System.out.println("Users in DB:");
		userRepository.findAll().forEach(u -> System.out.println(u.getUsername()));
	}
}
