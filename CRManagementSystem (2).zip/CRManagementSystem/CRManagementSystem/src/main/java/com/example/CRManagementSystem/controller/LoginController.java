package com.example.CRManagementSystem.controller;

import com.example.CRManagementSystem.model.User;
import com.example.CRManagementSystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")  // allows frontend HTML/JS to call backend
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    // Login API
    @PostMapping("/login")
    public String loginUser(@RequestBody User userData) {
        // Find user by username (not by ID)
        User user = userRepository.findByUsername(userData.getUsername());

        if (user == null) {
            return "User not found!";
        }

        if (user.getPassword().equals(userData.getPassword())) {
            return "Login successful!";
        } else {
            return "Invalid password!";
        }
    }
}
