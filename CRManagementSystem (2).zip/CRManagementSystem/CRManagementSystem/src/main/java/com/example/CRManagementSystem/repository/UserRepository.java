package com.example.CRManagementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.CRManagementSystem.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Custom query method for login
    User findByUsernameAndPassword(String username, String password);

    User findByUserId(String userId);
    User findByUsername(String username);
}
